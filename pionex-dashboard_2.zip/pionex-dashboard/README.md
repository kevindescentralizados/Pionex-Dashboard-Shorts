# Dashboard Descentralizados · Operativa short de Pionex (auto-actualizado)

Dashboard de resultados que se mantiene al día **solo**, sin que toques nada.
La automatización vive en un repositorio de GitHub: una GitHub Action se ejecuta
cada 15 minutos, descarga tus operaciones nuevas de la API de Pionex, recalcula
las métricas y publica el dashboard. El propio repositorio hace de base de datos
(carpeta `store/`), así que tu histórico nunca se pierde aunque la API solo
devuelva los últimos ~3 meses.

```
collector/
  pionex_client.py   cliente REST firmado (HMAC-SHA256)
  compute.py         reconstrucción de operaciones + métricas -> data.json
  seed_from_csv.py   siembra el histórico desde tus CSV (una vez)
  collect.py         entrypoint programado (API -> store -> data.json)
store/               la "BBDD": positions/fills/funding en JSONL (se commitea)
seed/                aquí van tus CSV de Pionex (ya incluidos)
site/                el dashboard (index.html + data.json publicados)
.github/workflows/   la automatización
```

## Importante antes de empezar

- **La API de futuros de Pionex es "invite-only / beta".** Los endpoints existen,
  pero puede que tengas que solicitar acceso a futuros desde tu cuenta. Mientras
  tanto el dashboard funciona igual con la semilla (tus CSV) y empezará a añadir
  operaciones nuevas en cuanto la API responda.
- **Clave SOLO LECTURA.** Crea la API key en https://www.pionex.com/en/apiKey con
  permiso *Read/View* únicamente. **Nunca** actives Trade ni Withdraw, y
  restringe la clave a una IP si puedes. El secreto vive como *GitHub Secret*:
  nunca se escribe en el sitio publicado.
- **Repositorio PRIVADO.** El `store/` y `data.json` contienen tu operativa.
  Mantén el repo en privado. Ten en cuenta que GitHub Pages publica el sitio en
  una URL accesible; si no quieres que tus resultados sean alcanzables por esa
  URL, no actives Pages y consulta el dashboard en local (ver más abajo).

## Puesta en marcha (una vez)

1. **Crea la API key** de solo lectura en Pionex y guarda key + secret.
2. **Sube este proyecto** a un repositorio de GitHub **privado**.
3. **Secrets del repo:** *Settings → Secrets and variables → Actions → New
   repository secret*. Crea `PIONEX_KEY` y `PIONEX_SECRET`.
4. **Tus CSV** ya están en `seed/` (`position_futures.csv` y
   `raw-trading-details.csv`). Si en el futuro quieres re-sembrar con un export
   más reciente, sustitúyelos y borra `store/positions.jsonl`.
5. **Activa Pages:** *Settings → Pages → Source: GitHub Actions*.
6. **Lanza la primera ejecución:** *Actions → Actualizar dashboard → Run
   workflow*. Al terminar tendrás la URL del dashboard en el job *deploy*.

A partir de ahí se actualiza solo cada 15 minutos. Puedes cambiar la frecuencia
en `.github/workflows/update.yml` (línea `cron`).

## Verificar la API (recomendado la primera vez)

Como los nombres de campos/paths de futuros pueden variar según tu acceso,
ejecuta el modo *probe* para ver la respuesta cruda y confirmar:

```bash
export PIONEX_KEY=...  PIONEX_SECRET=...
python collector/collect.py --probe
```

Si algún endpoint falla, ajusta `ENDPOINTS` en `collector/pionex_client.py` o el
mapeo de campos en `normalize_fill` / `normalize_funding` de `collector/collect.py`
con los nombres reales que veas en el probe. La parte de semilla no se ve
afectada por esto.

## Uso en local (opcional, 100% privado)

```bash
pip install -r requirements.txt
python collector/seed_from_csv.py      # siembra desde seed/ (solo la 1ª vez)
python collector/collect.py            # baja API (si hay claves) + regenera data.json
cd site && python -m http.server 8000  # abre http://localhost:8000
```

Ábrelo siempre por HTTP (`http.server`), no con doble clic en el archivo: el
dashboard hace `fetch('./data.json')` y el navegador lo bloquea desde `file://`.

## Qué muestra

KPIs (balance neto, win rate, rentabilidad media, media diaria), barras de PnL
neto por día, donut de ganadoras/perdedoras y el desglose por día con cada
operación (activo, nº de entradas, ganancia neta y rentabilidad %). Mismas reglas
validadas: cifras netas (incluyen comisiones y funding); las operaciones de
rebalanceo automático y las reentradas dudosas van marcadas aparte.

## Notas

- El cursor de descarga se guarda en `store/state.json`; cada run pide solo lo
  nuevo desde la última vez.
- `store/` se commitea automáticamente: ahí queda tu histórico completo.
- El dashboard se auto-refresca en el navegador cada 5 minutos.
